<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
    Error 404 | District Court, Patna | India    </title>
    <link rel="profile" href="http://gmpg.org/xfn/11" />
    <link rel="pingback" href="https://patna.dcourts.gov.in/xmlrpc.php" />
    <link rel="stylesheet" href="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/css/print.css" type="text/css" media="print">
        <meta name='robots' content='max-image-preview:large' />
	<style>img:is([sizes="auto" i], [sizes^="auto," i]) { contain-intrinsic-size: 3000px 1500px }</style>
	<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/patna.dcourts.gov.in\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.8.1"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\ud83d\udd25","\ud83d\udc26\u200b\ud83d\udd25")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://patna.dcourts.gov.in/wp-includes/css/dist/block-library/style.min.css?ver=6.8.1' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='extra-feature-css-css' href='https://patna.dcourts.gov.in/wp-content/plugins/common_utility/css/extra.features.css?ver=1.1' media='all' />
<link rel='stylesheet' id='contact-form-7-css' href='https://patna.dcourts.gov.in/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.3.2' media='all' />
<link rel='stylesheet' id='ecourt-services-style-css' href='https://patna.dcourts.gov.in/wp-content/plugins/ecourt/css/style.css?ver=6.8.1' media='all' />
<link rel='stylesheet' id='ecourt-services-select2-css' href='https://patna.dcourts.gov.in/wp-content/plugins/ecourt/css/select2.min.css?ver=6.8.1' media='all' />
<link rel='stylesheet' id='parichay-login-css-css' href='https://patna.dcourts.gov.in/wp-content/plugins/parichay-sso//css/login.css?ver=1.1' media='all' />
<link rel='stylesheet' id='wsl-widget-css' href='https://patna.dcourts.gov.in/wp-content/plugins/wordpress-social-login/assets/css/style.css?ver=6.8.1' media='all' />
<link rel='stylesheet' id='base-css-css' href='https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/css/base.css?ver=6.8.1' media='all' />
<link rel='stylesheet' id='sliderhelper-css-css' href='https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/css/addons/sliderhelper.css?ver=6.8.1' media='all' />
<link rel='stylesheet' id='main-css-css' href='https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/style.css?ver=6.8.1' media='all' />
<link rel='stylesheet' id='jquery-ui-datepicker-css' href='https://patna.dcourts.gov.in/wp-content/plugins/awaas-metaboxes/css/jquery.ui.datepicker.css?ver=1.0' media='all' />
<link rel='stylesheet' id='fontawesome-css' href='https://patna.dcourts.gov.in/wp-content/plugins/awaas-accessibility/css/font-awsome.css?ver=6.8.1' media='all' />
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/js/jquery.min.js?ver=3.6.4" id="jquery-core-js"></script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/js/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/plugins/awaas-accessibility/js/external.js?ver=6.8.1" id="external-link-js"></script>
<link rel="https://api.w.org/" href="https://patna.dcourts.gov.in/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://patna.dcourts.gov.in/xmlrpc.php?rsd" />
    <noscript>
        <style>
            #topBar #accessibility ul li .goiSearch, #topBar1 #accessibility ul li .goiSearch{ visibility: visible;}
            #topBar #accessibility ul li .socialIcons ul, #topBar1 #accessibility ul li .socialIcons ul { background: #fff !important;}
            #topBar #accessibility ul li .goiSearch, #topBar1 #accessibility ul li .goiSearch{ right: 0; left: inherit;}
            .nav li a:focus > ul { left: 0; opacity: 0.99;}
            a:focus, button:focus, .carasoleflex-wrap .flexslider .slides > li a:focus, .flexslider .slides>li a:focus
            { outline: 3px solid #ff8c00 !important;}
            .flexslider .slides>li { display:block !important;}
            .flexslider .slides img { width:auto !important;}
            .nav li.active > a, .nav li > a:hover, .nav li > a:focus, .nav ul li a:hover,
            .nav li:hover > a{ border-top:none; color:#ffffff;}
            .nav li.active > a{ border:0;}
            .nav ul{ opacity:1; left:0; position:static !important; width:auto; border:0;}
            .nav li{ position:static !important; display:block; float:none; border:0 !important;}

            .nav li > a { float: none;  display: block;  background-color: #ff9f08 !important;  color: #ffffff; margin: 0; padding: 0px 15px;
                border-radius: 0; border-bottom: 1px solid #ffffff !important;   position: static !important;  border-top: 0;  font-size: 14px !important;}

            .nav ul.sub-menu li > a{ background-color:#464141 !important; font-size:12px !important; padding:0 25px;}

            .style-1 .menuWrapper, .style-2 .menuWrapper, .style-6 .menuWrapper, .style-5 .menuWrapper{ background:#e1e1e1 !important;}
            .style-1 .nav li > a, .style-1 .nav li > a:hover{background-color: #875506 !important;}
            .style-1 .nav ul.sub-menu li > a, .style-1 .nav ul.sub-menu li > a:hover{ background-color:#3e2908 !important;}

            .style-2 .nav li > a, .style-2 .nav li > a:hover{background-color: #11372a !important;}
            .style-2 .nav ul.sub-menu li > a, .style-2 .nav ul.sub-menu li > a:hover{ background-color:#677314 !important;}

            .style-6 .nav li > a, .style-6 .nav li > a:hover{background-color: #f65a64 !important;}
            .style-6 .nav ul.sub-menu li > a:hover{ background-color:#fff !important;}
            .style-6 .nav ul.sub-menu li > a { background-color:transparent !important; }
            .style-6 .menuWrapper .nav li ul li{ border-bottom:1px solid transparent !important;}
            .style-6 .menuWrapper .nav li a{ border-radius:0 !important; color:#fff !important;}
            .style-6 .menuWrapper .nav li a:hover{ color:#000 !important;}

            .style-5 .nav li > a, .style-5 .nav li > a:hover{background-color: #fd9c29 !important; color:#ffffff !important;}
            .style-5 .nav ul.sub-menu li > a, .style-5 .nav ul.sub-menu li > a:hover{ background-color:#464141 !important; color:#ffffff !important;}
            .style-6 .menuWrapper .nav li ul li a {    margin: 0;    padding: 7px 15px;}

            ul li .socialIcons{ visibility:visible !important;}

        </style>
    </noscript>
        <style> div.no-script-service-form { display:none;visibility: hidden } </style>
    <noscript>
    <style>
        div.custom-form-cntr.ecourt-services-form { display:none; visibility: hidden; }
        div.no-script-service-form { display:block;visibility: visible; }
    </style>
</noscript>
<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/js/html5shiv.min.js"></script>
    <script src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/js/respond.min.js"></script>
    <![endif]-->
    <script>
        var ajaxurl = "https://patna.dcourts.gov.in/wp-admin/admin-ajax.php";
    </script>
    
    <style>
        p.errorInfo{display:none;}
    </style>

</head>

<body class="error404 wp-theme-sdo-theme lang-en style-4 home-4 wpb-js-composer js-comp-ver-6.5.0 vc_responsive">
<header id="mainHeader">

    <!--topBar start-->
    <div id="topBar">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="push-right" aria-label="Primary">
                        <div id="accessibility">
                            <ul id="accessibilityMenu" class="clearfix">
                                <li>
                                    <a href="#SkipContent" class="skipContent" aria-label="Skip to main content" title="Skip to main content">
                                        <span class="m-hide">Skip to main content</span>
                                        <span class="icon-skip-to-main m-show"></span>
                                    </a>
                                </li>
                                <li class="searchbox">
                                    <a href="javascript:void(0);" title="Site Search" aria-label="Site Search" role="button" data-toggle="dropdown">
                                        <img class="show-con" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/search_icon.svg" title="Search Icon" alt="Search Icon" />
                                    </a>
                                    <div class="goiSearch">
                                        <form action="https://patna.dcourts.gov.in/" method="get">
                                            <label for="search" class="hide">Search</label>
                                            <input type="search" placeholder="Search here..." name="s" id="search" value="" />
                                            <button class="accent-color accent-border-color" type="submit" title="Search"><span class="icon-search" ></span><span class="hide">Search</span></button>
                                        </form>
                                    </div>
                                </li>
                                                                    <li class="social-media">
                                        <a href="javascript:void(0);" class="social-group-icon" title="Social Media Links" aria-label="Social Media Links" role="button" data-toggle="dropdown">
                                        <img class="show-con" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/social_media.svg" title="Social Icon" alt="Social Icon" /> 
                                        <span class="hide">Social Media Links</span> 
                                        </a>
                                        <ul class="socialIcons">
                                                                                                                                                                                    <li><a href="https://www.youtube.com/channel/UCPMHFB1lou-P_YtErFFYjgw" target="_blank" aria-label="Youtube | External site that opens in a new window"><img src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/youtube_icon.svg" title="Youtube | External site that opens in a new window" alt="youtube, External Link that opens in a new window"></a></li>
                                                                                    </ul>
                                    </li>
                                																<li class="top-sitemap">
                                    <a href="https://patna.dcourts.gov.in/sitemap/" aria-label="Sitemap"  title="Sitemap">
                                    <img class="show-con" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/sitemap_icon.svg" title="Sitemap Icon" alt="Sitemap Icon" />
                                    <span class="hide">Sitemap</span></a></li>                                 <li>
                                    <a href="javascript:void(0);" title="Accessibility Links" aria-label="Accessibility Links" class="accessible-icon" role="button" data-toggle="dropdown"><span class="tcon">Accessibility Links</span>
                                        <!--span class="icon-accessibility" aria-hidden="true"></span-->
                                        <img class="show-con" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/accessibility_icon.svg" title="Accessibility Icon" alt="Accessibility Icon" />
                                    </a>
                                    <ul class="accessiblelinks textSizing" aria-label="Font size and Contrast controls">
                                        <li class="fontSizeEvent"><a data-selected-text="selected" data-event-type="increase" href="javascript:void(0);" data-label="Font Size Increase" title="Font Size Increase" aria-label="Font Size Increase"><span aria-hidden="true">A+</span> <span class="tcon">Font Size Increase</span></a></li>
                                        <li class="fontSizeEvent"><a data-selected-text="selected" data-event-type="normal" href="javascript:void(0);" data-label="Normal Font" title="Normal Font" aria-label="Normal Font"><span aria-hidden="true">A</span> <span class="tcon">Normal Font - Selected</span></a></li>
                                        <li class="fontSizeEvent" ><a data-selected-text="selected" data-event-type="decrease" href="javascript:void(0);" data-label="Font Size Decrease" title="Font Size Decrease" aria-label="Font Size Decrease"><span aria-hidden="true">A-</span> <span class="tcon">Font Size Decrease</span></a></li>
                                        <li class="highContrast dark tog-con">
                                            <a href="javascript:void(0);" title="High Contrast" aria-label="High Contrast"><span aria-hidden="true">A</span> <small class="tcon">High Contrast</small></a>
                                        </li>
                                        <li class="highContrast light">
                                            <a class="link-selected" href="javascript:void(0);" title="Normal Contrast - Selected" aria-label="Normal Contrast - Selected"><span aria-hidden="true">A</span> <small class="tcon">Normal Contrast</small></a>
                                        </li>
                                    </ul>
                                </li>
                                                                    <li class="languageCont link-selected" aria-label="Change Language">
                                    <a href="javascript:void(0);" class="language link-selected" aria-label="English - Selected" title="English - Selected" role="button" data-toggle="dropdown">English</a>
                                        <ul class="socialIcons">
                                                                                </ul>
                                    </li>
                                                            </ul>
                        </div>
                    </div>
                    <div class="push-left">
                        <div class="govBranding">
                            <ul>
                                <li>
                                    <a lang="" href="https://ecommitteesci.gov.in/hi" >
                                        इ-कमिटी, उच्चतम न्यायालय, भारत                                    </a></li>
                                <li>
                                    <a lang="en" href="https://ecommitteesci.gov.in/">
                                        E-COMMITTEE, SUPREME COURT OF INDIA                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--topBar end-->

    <!--header middle start-->
    <div class="header-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-8 col-xs-7">
                    <div class="logo">

                        <a href="https://patna.dcourts.gov.in/" title="Go to home" class="site_logo" rel="home">
                                                        		<img id="logo" class="emblem" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/emblem.svg" alt="State Emblem of India">
                                                    	
                            <div class="logo_text">
                                <strong lang="">
                                    जिला अदालत, पटना                                </strong>
                                                                    <span class="site_name_english">District Court, Patna</span>
                                                                                                    <span class="logo-sub-title">e-Courts Mission Mode Project</span>
                                                            </div>
                        </a>

                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-5">
                    <div class="header-right hidden-xs push-right">
                                                                                                                            <a aria-label="Digital India - External site that opens in a new window" href="https://www.digitalindia.gov.in/" target= "_blank" title="Digital India">
                                <img class="sw-logo" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/digital-india.png" alt="Digital India">
                            </a>
                                            </div>
                    <a class="menuToggle" href="javascript:void(0);"> <span class="icon-menu" aria-hidden="true"></span> <span class="menu-text">Menu Toggle</span> </a>
                </div>
            </div>
        </div>
    </div>
    <!--header middle end-->

    <!--main menu start-->
    <div class="menuWrapper">

        <div class="menuMoreText hide">More</div>


        <div class="container">
            <nav class="menu"><ul id="menu-header-en" class="nav clearfix"><li id="menu-item-5049" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5049"><a href="/">Home</a></li>
<li id="menu-item-5050" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5050 has-sub"><a href="#" aria-haspopup="true" aria-expanded="false">About Court<span class="indicator"></span></a>
<ul aria-hidden="true"  class="sub-menu">
	<li id="menu-item-5894" class="menu-item menu-item-type-post_type menu-item-object-about-department menu-item-5894 has-sub-child"><a href="https://patna.dcourts.gov.in/about-department/history/" tabindex="-1">History</a></li>
	<li id="menu-item-5043" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5043 has-sub-child"><a href="https://patna.dcourts.gov.in/list-of-judges/" tabindex="-1">List of Judges</a></li>
	<li id="menu-item-5042" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5042 has-sub-child"><a href="https://patna.dcourts.gov.in/former-judges/" tabindex="-1">Former Judges</a></li>
	<li id="menu-item-5041" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5041 has-sub-child"><a href="https://patna.dcourts.gov.in/judges-on-leave/" tabindex="-1">Judges on Leave</a></li>
	<li id="menu-item-5040" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5040 has-sub-child"><a href="https://patna.dcourts.gov.in/holiday-list/" tabindex="-1">Holiday List</a></li>
	<li id="menu-item-5048" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5048 has-sub-child"><a href="https://patna.dcourts.gov.in/contact-us/" tabindex="-1">Contact Us</a></li>
</ul>
</li>
<li id="menu-item-5051" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5051"><a href="https://main.sci.gov.in/">Supreme Court</a></li>
<li id="menu-item-5038" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5038"><a href="https://patna.dcourts.gov.in/high-court/">High Court</a></li>
<li id="menu-item-5230" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5230 has-sub"><a href="#" aria-haspopup="true" aria-expanded="false">Services<span class="indicator"></span></a>
<ul aria-hidden="true"  class="sub-menu">
	<li id="menu-item-5772" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5772 has-sub has-sub-child"><a href="#" tabindex="-1" aria-haspopup="true" aria-expanded="false">Case Status<span class="indicator"></span></a>
	<ul aria-hidden="true"  class="sub-menu">
		<li id="menu-item-5254" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5254 has-sub-child"><a href="https://patna.dcourts.gov.in/case-status-search-by-case-number/" tabindex="-1">Case Number</a></li>
		<li id="menu-item-5248" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5248 has-sub-child"><a href="https://patna.dcourts.gov.in/case-status-search-by-case-type/" tabindex="-1">Case Type</a></li>
		<li id="menu-item-5253" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5253 has-sub-child"><a href="https://patna.dcourts.gov.in/case-status-search-by-fir-number/" tabindex="-1">FIR Number</a></li>
		<li id="menu-item-5250" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5250 has-sub-child"><a href="https://patna.dcourts.gov.in/case-status-search-by-filing-number/" tabindex="-1">Case Code</a></li>
		<li id="menu-item-5255" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5255 has-sub-child"><a href="https://patna.dcourts.gov.in/case-status-search-by-petitioner-respondent/" tabindex="-1">Party Name</a></li>
		<li id="menu-item-5251" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5251 has-sub-child"><a href="https://patna.dcourts.gov.in/case-status-search-by-advocate/" tabindex="-1">Advocate Name</a></li>
		<li id="menu-item-5249" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5249 has-sub-child"><a href="https://patna.dcourts.gov.in/case-status-search-by-act-type/" tabindex="-1">Act</a></li>
	</ul>
</li>
	<li id="menu-item-5773" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5773 has-sub has-sub-child"><a href="#" tabindex="-1" aria-haspopup="true" aria-expanded="false">Court Order<span class="indicator"></span></a>
	<ul aria-hidden="true"  class="sub-menu">
		<li id="menu-item-5247" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5247 has-sub-child"><a href="https://patna.dcourts.gov.in/court-orders-search-by-case-number/" tabindex="-1">Case Number</a></li>
		<li id="menu-item-5244" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5244 has-sub-child"><a href="https://patna.dcourts.gov.in/court-orders-search-by-order-date/" tabindex="-1">Order Date</a></li>
		<li id="menu-item-5246" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5246 has-sub-child"><a href="https://patna.dcourts.gov.in/court-orders-search-by-court-number/" tabindex="-1">Court Number</a></li>
		<li id="menu-item-5245" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5245 has-sub-child"><a href="https://patna.dcourts.gov.in/court-orders-search-by-party-name/" tabindex="-1">Party Name</a></li>
	</ul>
</li>
	<li id="menu-item-5243" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5243 has-sub-child"><a href="https://patna.dcourts.gov.in/cause-list-%e2%81%84-daily-board/" tabindex="-1">Cause List</a></li>
	<li id="menu-item-5335" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5335 has-sub-child"><a href="https://patna.dcourts.gov.in/caveat-search/" tabindex="-1">Caveat Search</a></li>
</ul>
</li>
<li id="menu-item-5052" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5052"><a href="https://indiacode.nic.in/">India Code</a></li>
<li id="menu-item-5586" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5586 has-sub"><a href="#" aria-haspopup="true" aria-expanded="false">Documents<span class="indicator"></span></a>
<ul aria-hidden="true"  class="sub-menu">
	<li id="menu-item-5587" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5587 has-sub-child"><a href="https://patna.dcourts.gov.in/documents/" tabindex="-1">All Documents</a></li>
	<li id="menu-item-6178" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6178 has-sub-child"><a href="https://patna.dcourts.gov.in/forms/" tabindex="-1">Forms</a></li>
	<li id="menu-item-5055" class="menu-item menu-item-type-taxonomy menu-item-object-document-category menu-item-5055 has-sub-child"><a href="https://patna.dcourts.gov.in/document-category/circular-notices/" tabindex="-1">Circular Notices</a></li>
	<li id="menu-item-5056" class="menu-item menu-item-type-taxonomy menu-item-object-document-category menu-item-5056 has-sub-child"><a href="https://patna.dcourts.gov.in/document-category/management-tools/" tabindex="-1">Management Tools</a></li>
	<li id="menu-item-5057" class="menu-item menu-item-type-taxonomy menu-item-object-document-category menu-item-5057 has-sub-child"><a href="https://patna.dcourts.gov.in/document-category/notification/" tabindex="-1">Notification</a></li>
	<li id="menu-item-5058" class="menu-item menu-item-type-taxonomy menu-item-object-document-category menu-item-5058 has-sub-child"><a href="https://patna.dcourts.gov.in/document-category/performance-measurement-report/" tabindex="-1">Performance Measurement Report</a></li>
	<li id="menu-item-5059" class="menu-item menu-item-type-taxonomy menu-item-object-document-category menu-item-5059 has-sub-child"><a href="https://patna.dcourts.gov.in/document-category/pleaders-and-bar-association/" tabindex="-1">Pleaders and Bar Association</a></li>
	<li id="menu-item-5060" class="menu-item menu-item-type-taxonomy menu-item-object-document-category menu-item-5060 has-sub-child"><a href="https://patna.dcourts.gov.in/document-category/rules-and-regulations/" tabindex="-1">Rules and Regulations</a></li>
	<li id="menu-item-5061" class="menu-item menu-item-type-taxonomy menu-item-object-document-category menu-item-5061 has-sub-child"><a href="https://patna.dcourts.gov.in/document-category/statistical-reports/" tabindex="-1">Statistical Reports</a></li>
</ul>
</li>
<li id="menu-item-5072" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5072 has-sub"><a href="#" aria-haspopup="true" aria-expanded="false">Notices<span class="indicator"></span></a>
<ul aria-hidden="true"  class="sub-menu">
	<li id="menu-item-5070" class="menu-item menu-item-type-taxonomy menu-item-object-notice-category menu-item-5070 has-sub-child"><a href="https://patna.dcourts.gov.in/notice-category/tenders/" tabindex="-1">Tenders</a></li>
	<li id="menu-item-5071" class="menu-item menu-item-type-taxonomy menu-item-object-notice-category menu-item-5071 has-sub-child"><a href="https://patna.dcourts.gov.in/notice-category/recruitments/" tabindex="-1">Recruitments</a></li>
</ul>
</li>
<li id="menu-item-5062" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5062 has-sub"><a href="#" aria-haspopup="true" aria-expanded="false">Magistrate<span class="indicator"></span></a>
<ul aria-hidden="true"  class="sub-menu">
	<li id="menu-item-6431" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6431 has-sub-child"><a href="https://patna.dcourts.gov.in/duty-magistrate/" tabindex="-1">Duty Magistrate</a></li>
	<li id="menu-item-6434" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6434 has-sub-child"><a href="https://patna.dcourts.gov.in/police-station-wise-magistrate/" tabindex="-1">Police Station Wise Magistrate</a></li>
</ul>
</li>
<li id="menu-item-5466" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5466 has-sub"><a href="#" aria-haspopup="true" aria-expanded="false">Media Gallery<span class="indicator"></span></a>
<ul aria-hidden="true"  class="sub-menu">
	<li id="menu-item-5467" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5467 has-sub-child"><a href="https://patna.dcourts.gov.in/photo-gallery/" tabindex="-1">Photo Gallery</a></li>
	<li id="menu-item-5475" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5475 has-sub-child"><a href="https://patna.dcourts.gov.in/video-gallery/" tabindex="-1">Video Gallery</a></li>
	<li id="menu-item-5468" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5468 has-sub-child"><a href="https://patna.dcourts.gov.in/category/news/" tabindex="-1">News</a></li>
	<li id="menu-item-5469" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5469 has-sub-child"><a href="https://patna.dcourts.gov.in/category/press-release/" tabindex="-1">Press Release</a></li>
	<li id="menu-item-5767" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5767 has-sub has-sub-child"><a href="#" tabindex="-1" aria-haspopup="true" aria-expanded="false">Publications<span class="indicator"></span></a>
	<ul aria-hidden="true"  class="sub-menu">
		<li id="menu-item-5768" class="menu-item menu-item-type-taxonomy menu-item-object-publication-type menu-item-5768 has-sub-child"><a href="https://patna.dcourts.gov.in/publication-type/brochures/" tabindex="-1">Brochures</a></li>
		<li id="menu-item-5770" class="menu-item menu-item-type-taxonomy menu-item-object-publication-type menu-item-5770 has-sub-child"><a href="https://patna.dcourts.gov.in/publication-type/newsletters/" tabindex="-1">Newsletters</a></li>
	</ul>
</li>
</ul>
</li>
</ul></nav>
        </div>
    </div>
    <!--main menu end-->

    <div id="overflowMenu">
        <div class="ofMenu">
            <ul></ul>
        </div>
        <a href="#" title="Close" class="closeMenu" tabindex="-1"><span class="icon-close" aria-hidden="true"></span> Close</a>
    </div>

</header>


<main>

<div id="SkipContent"></div>
    <section class="section-row">
		<div class="container">
        	
	<div class="page-head">
  <div class="row">
    <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
      <div id="breadcrumb" class="push-left" role="navigation" aria-label="breadcrumb">
        <ul class="breadcrumbs"><li><a href="https://patna.dcourts.gov.in/"  class="home"><span>Home</span></a></li> <li class="current">Error 404</li></ul><!-- .breadcrumbs -->      </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
      <div class="printShare push-right">
                  <ul>
          <li>
            <a href="#" id="print" aria-label="Print Page Content" title="Print Page Content" ><span class="hide">Print</span>
            <img class="inr-bred-icon" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/print_icon.svg" title="Print Icon" alt="Print Icon"/>
            </a>
					</li>
          <li aria-hidden="true">
            <img aria-hidden="true" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/share_icon.svg" title="Share Icon" alt="Share Icon" />
            <span class="hide">Share</span>
					</li>
					<li>
            <a class="bread-fb" aria-label="Share on Facebook - opens a new window" href="https://www.facebook.com/sharer/sharer.php?u=&t="
             onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;"
             target="_blank" title="Share on Facebook">
             <img class="inr-bred-icon" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/facebook_social_icon.svg" title="Facebook Icon" alt="Facebook Icon" />
             <span class="hide">Share on Facebook</span></a>
					</li>
					<li>
            <a class="bread-twt" aria-label="Share on Twitter - opens a new window" href="https://twitter.com/share?url=&via=TWITTER_HANDLE&text="
            onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;"
            target="_blank" title="Share on Twitter">
            <img class="inr-bred-icon twitter-con" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/twitter_social_icon.svg" title="Twitter Icon" alt="Twitter Icon" />
            <span class="hide">Share on Twitter</span></a>
          </li>
          <li>
            <a class="bread-lnd" aria-label="Share on Linkedin - opens a new window" href="http://www.linkedin.com/sharing/share-offsite/?url=&mini=true"
            onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;"
            target="_blank" title="Share on Linkedin">
            <img class="inr-bred-icon" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/linkedin_social_icon.svg" title="Linkedin Icon" alt="Linkedin Icon" />
            <span class="hide">Share on Linkedin</span></a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>

    <div id="row-content">
            <div class="switchViewHead">
               <div class="row">
                   <div class="col-lg-11 col-md-11 col-sm-11 col-xs-12">
                       <h1>404 Not Found, Sorry For the Inconvenience</h1>
                   </div>
                   <div class="col-lg-1 col-md-1 col-sm-1 hidden-xs hide">
                       <div class="viewSwicther push-right clearfix">
                           <a href="#" class="thumbs-view-btn"><span class="icon-thumbs-view"></span></a>
                           <a href="#" class="thumbs-list-view-btn"><span class="icon-list-view"></span></a>
                       </div>
                   </div>
               </div>
           	</div>

			<div class="data-table-container">
            	<div class="row">
                	<div class="col-xs-12">
                    <form action="https://patna.dcourts.gov.in/" method="get">
                        <div class="search-main-container odd">
                            <div class="search-container">
                            	<div class="search-area clearfix">

                                        <input class="form-control" type="text" name="s" placeholder="Search" value="" />
                                        <button type="submit" class="btn" title="Search"><span class="icon-search"></span> Search</button>

                                </div>
                            </div>
                        </div>
                        </form>

                        <div class="box border">
                            <div class="center-block-box textCenter">
                            	<h3 class="font-regular">Error 404: Page Not Found</h3>
                            	<div class="separator15"></div>
								<img src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/404.png" alt="404 Error">
                                <div class="separator30"></div>
                                <p><a title="Feedback" href="https://patna.dcourts.gov.in/feedback/"  class="btn btn-default"><span class="icon-email"></span> Feedback </a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
	</section>
</main>

<footer id="mainFooter">
    <div class="footer-top">
        <div class="container">
            <div class="col-xs-12 text-center">
                <div class="footerMenu"><ul id="menu-footer-en" class="menu"><li id="menu-item-738" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-738"><a href="https://patna.dcourts.gov.in/feedback/">Feedback</a></li>
<li id="menu-item-737" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-737"><a href="https://patna.dcourts.gov.in/website-policies/">Website Policies</a></li>
<li id="menu-item-736" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-736"><a href="https://patna.dcourts.gov.in/contact-us/">Contact Us</a></li>
<li id="menu-item-735" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-735"><a href="https://patna.dcourts.gov.in/help/">Help</a></li>
<li id="menu-item-5064" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5064"><a href="https://patna.dcourts.gov.in/disclaimer/">Disclaimer</a></li>
</ul></div>            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 text-center">
                    
                    <div class="copyRights"> <div class="copyRightsText">
					<p class="mr-none">Content Owned by                                        District Court Patna 
                                    </p>
				<p>Developed and hosted by <a href="http://www.nic.in/" target="_blank">National Informatics Centre</a>, <br><a href="http://meity.gov.in/" target="_blank">Ministry of Electronics & Information Technology</a>, Government of India</p>
                            <p>Last Updated: <strong>Jul 14, 2025</strong></p>                        </div>

                        <ul class="copyRightsLogos">
                            <li><a href="https://s3waas.gov.in/" aria-label="S3WaaS Logo, link to external site https://s3waas.gov.in/ opens in a new window" title="S3WaaS Logo, link to external site https://s3waas.gov.in/ opens in a new window"><img src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/s3waas.png"  alt="Secure, Scalable and Sugamya Website as a Service"></a></li>
                            <li><a href="http://www.digitalindia.gov.in/" aria-label="Digital India Logo, link to external site http://www.digitalindia.gov.in/ opens in a new window" title="Digital India Logo, link to external site http://www.digitalindia.gov.in/ opens in a new window"><img src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/digitalIndia.png" alt="Digital India"></a></li>
                            <li><a href="http://www.doj.gov.in/" aria-label="Department of Justice Logo, link to external site http://www.doj.gov.in/ opens in a new window" title="Department of Justice Logo, link to external site http://www.doj.gov.in/ opens in a new window"><img src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/Department_of_Justice.png"  alt="Department of Justice"></a></li>
                            <li><a href="https://ecommitteesci.gov.in/" aria-label="e-Committee Supreme Court of India Logo, link to external site https://ecommitteesci.gov.in/ opens in a new window" title="e-Committee Supreme Court of India Logo, link to external site https://ecommitteesci.gov.in/ opens in a new window"><img src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/ecommittee-logo.png"  alt="e-Committee Supreme Court of India"></a></li>
                            <li><a href="https://www.indiacode.nic.in/" aria-label="India Code Logo, link to external site https://www.indiacode.nic.in/ opens in a new window" title="India Code Logo, link to external site https://www.indiacode.nic.in/ opens in a new window"><img src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/IC-logo.png"  alt="India Code"></a></li>
                            <li><a href="http://www.nic.in/" aria-label="National Informatics Centre Logo, link to external site http://www.nic.in/ opens in a new window" title="National Informatics Centre Logo, link to external site http://www.nic.in/ opens in a new window"><img src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/images/nicLogo.png"  alt="National Informatics Centre"></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<!--a class="top" href="#top"><span class="icon-arrow-top"></span></a-->

<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"\/*"},{"not":{"href_matches":["\/wp-*.php","\/wp-admin\/*","\/s3ec05a18630ab1c3b9f14454cf70dc711\/uploads\/*","\/wp-content\/*","\/wp-content\/plugins\/*","\/wp-content\/themes\/sdo-theme\/*","\/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
    <script>

        jQuery(document).ready(function($){

            if (!String.prototype.startsWith) {
                    String.prototype.startsWith = function(searchString, position){
                    position = position || 0;
                    return this.substr(position, searchString.length) === searchString;
                };
            }

            jQuery('body').on('targetExternalLinks',function(){

                var isExternal = function(url) {
                    if( !url.match('^(https?:)?(\\/\\/).*$')) return false;
                    return !(location.href.replace("http://", "").replace("https://", "").split("/")[0] === url.replace("http://", "").replace("https://", "").split("/")[0]);
                }
                jQuery('a').each(function(){
                    var href = jQuery(this).attr('href');
                    if(typeof href == 'undefined' ){
                        jQuery(this).attr('href','javascript:void(0)');
                        href = '#';
                    }

                    if(jQuery(this).attr('hreflang') !== undefined){

                        if($(this).attr('hreflang') == 'od'){
                            $(this).attr({  hreflang: 'or', lang:'or'});
                        }

                        if(jQuery(this).attr('aria-label') !== typeof undefined){
                            jQuery(this).attr('aria-label', jQuery(this).text()).attr('title',jQuery(this).text());
                        }
                    }else if(isExternal(href)){

                            if(
                                href.indexOf('cdn.s3waas.gov.in') == -1 
                                && href.indexOf('auth.s3waas.gov.in') == -1
                                && href.indexOf('cdnbbsr.s3waas.gov.in') == -1
                                && href.indexOf('parichay') == -1
                                && !jQuery(this).hasClass('fancybox.iframe')
                                && !jQuery(this).hasClass('fancybox')
                              ) {
                                if(typeof jQuery(this).attr('onclick') === "undefined"){
                                    jQuery(this).attr("onclick", "return confirm('You are being redirected to an external website. Please note that District Court, Patna cannot be held responsible for external websites content & privacy policies.');");
                                }
                            }

                            if(typeof jQuery(this).attr('aria-label') === "undefined" || typeof jQuery(this).attr('title') === "undefined"){
                                var text = '';
                                if(jQuery(this).text().trim() !== ''){
                                    text = jQuery(this).text().trim()+' - ';
                                }else {
                                    text = jQuery(this).attr('href')+' - ';
                                }

                                if(
                                    href.indexOf('cdn.s3waas.gov.in') == -1 
                                    && href.indexOf('auth.s3waas.gov.in') == -1
                                    && href.indexOf('cdnbbsr.s3waas.gov.in') == -1
                                    && href.indexOf('parichay') == -1
                                    && !jQuery(this).hasClass('fancybox.iframe')
                                    && !jQuery(this).hasClass('fancybox')
                                ){

                                    if(typeof jQuery(this).attr('aria-label') === "undefined"){
                                        jQuery(this).attr('aria-label', text + 'External site that opens in a new window');
                                    }
                                    if(typeof jQuery(this).attr('title') === "undefined"){
                                        jQuery(this).attr('title', text + 'External site that opens in a new window');
                                    }

                                }
                            }

                            if(href.indexOf('auth.s3waas.gov.in') == -1 && href.indexOf('parichay') == -1) {
                                jQuery(this).prop('target', '_blank');
                                jQuery(this).prop('rel', 'noopener noreferrer');
                            }
                    }
                });

            })
            jQuery('body').trigger('targetExternalLinks');

            jQuery('.flex-direction-nav a.flex-prev').attr({'title' : 'Previous','aria-label':'Previous'});
			jQuery('.flex-pauseplay a.flex-pause').attr({'title' : 'Play/Pause','aria-label':'Play/Pause'});
			jQuery('.flex-direction-nav a.flex-next').attr({'title' : 'Next','aria-label':'Next'});

            jQuery('a[download]').each(function(){

                var ariaLabelPrevious = jQuery(this).prev().attr('aria-label');
                if(typeof ariaLabelPrevious !== typeof undefined){
                    var ariaLabel = jQuery(this).prev().attr('aria-label').split('-')[0];
                    ariaLabel = 'Download ' + ariaLabel;
                    jQuery(this).attr('aria-label',ariaLabel).removeAttr('aria-hidden');
                }
            });
        });
    </script>
    <script type="text/javascript" id="jquery-common-js-js-extra">
/* <![CDATA[ */
var AwaasData = {"ajaxUrl":"https:\/\/patna.dcourts.gov.in\/wp-admin\/admin-ajax.php","isUserLoggedIn":""};
/* ]]> */
</script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/plugins/common_utility/js/common.js?ver=1.1" id="jquery-common-js-js"></script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/plugins/ecourt/js/select2.min.js?ver=1.0.0" id="ecourt-select2-was-js"></script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/plugins/ecourt/js/datepicker.js?ver=1.0.0" id="ecourt-datepicker-was-js"></script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/plugins/ecourt/js/jquery.validate.min.js?ver=1.0.0" id="ecourt-jquery.validate-js"></script>
<script type="text/javascript" id="ecourt-services-api-js-extra">
/* <![CDATA[ */
var EcourtServicesData = {"currentLang":"en"};
/* ]]> */
</script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/plugins/ecourt/js/ecourt-services-api.js?ver=1.0.0" id="ecourt-services-api-js"></script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/js/core.min.js?ver=3.6.4" id="jquery-ui-core-js"></script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/js/datepicker.min.js?ver=1.1" id="jquery-ui-datepicker-js"></script>
<script type="text/javascript" id="jquery-ui-datepicker-js-after">
/* <![CDATA[ */
jQuery(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"Close","currentText":"Today","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Previous","dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"dateFormat":"MM d, yy","firstDay":1,"isRTL":false});});
/* ]]> */
</script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/js/ui/jquery.flexslider.js?ver=1.1" id="jquery-flexslider-js-js"></script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/js/easyResponsiveTabs.js?ver=1.1" id="jseasyResponsiveTabs-js"></script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/js/jquery.fancybox.js?ver=1.1" id="jqueryfancyboxjs-js"></script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/js/style.switcher.js?ver=1.1" id="styleswitcherjs-js"></script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/js/menu.js?ver=1.1" id="menujs-js"></script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/js/table.min.js?ver=1.1" id="tablejs-js"></script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/js/custom.js?ver=1.1" id="custom-js"></script>
<script type="text/javascript" src="https://patna.dcourts.gov.in/wp-content/themes/sdo-theme/js/extra.js?ver=1.1" id="extrajs-js"></script>
        <script>
            jQuery(document).ready(function ($) {
                $.post({
                    url: ajaxurl,
                    method: 'POST',
                    dataType: 'JSON',
                    data: {
                        time: new Date().getTime(),
                        lang: 'en',
                        action: 's3waas_pll_lang_cookie'
                    },
                    success: function (responseResults) {}
                })
            })
        </script>
        <!--Ecourts Instance-->
        <script type="text/javascript">
(function() {
				var expirationDate = new Date();
				expirationDate.setTime( expirationDate.getTime() + 31536000 * 1000 );
				document.cookie = "pll_language=en; expires=" + expirationDate.toUTCString() + "; path=/; domain=patna.dcourts.gov.in; secure; SameSite=Lax";
			}());

</script>
<script>
jQuery(document).ready(function($){
  jQuery('body').find('a.flex-pause').attr('href',"javascript:void(0)");
    $('.flex-direction-nav a.flex-prev').attr({'title' : 'Previous','aria-label':'Previous'});
    $('.flex-pauseplay a.flex-pause').attr({'title' : 'Play/Pause','aria-label':'Play/Pause'});
    $('.flex-direction-nav a.flex-next').attr({'title' : 'Next','aria-label':'Next'});

    $('.second_col input[type=text]').attr('autocomplete','off');
});
</script>
<!--ECourts Instance-->
</body>
</html>